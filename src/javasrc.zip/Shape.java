
/**
 * 
 * @author Malachi Swedberg
 */
public enum Shape{

	THIMBLE,
	BOOT,
	RACECAR;
	
	public String toString() {
		return this.name();
	}
}
