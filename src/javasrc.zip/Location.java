/**
 * 
 * @author Malachi Swedberg
 */
public enum Location{
	KITCHEN,
	CONSERVATORY,
	DINING_ROOM,
	BALLROOM,	
	STUDY,	
	HALL,
	LOUNGE,
	LIBRARY,
	BILLIARD_ROOM;
}
